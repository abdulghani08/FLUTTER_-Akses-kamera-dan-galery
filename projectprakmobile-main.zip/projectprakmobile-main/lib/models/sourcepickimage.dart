import 'package:flutter/material.dart';

Widget sourcepickimage(String source){
  return Container(
    child: Text(source, style: TextStyle(color: Colors.blueAccent, fontSize: 25),),
  );
}
