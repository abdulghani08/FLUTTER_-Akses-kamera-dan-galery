# akseskameradanstorage

A new Flutter project.
Untuk bisa berhasil di praktikum ini, pastikan runningnya pake emulator atau real device, jangan pake chrome etc.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

Step-1 
Unduh dependencies image_picker versi terbaru (https://pub.dev/packages/image_picker).

step-2 
Cek di pubspec.yaml, pastikan image_picker sudah terpasang. Setelah itu Pub get

step-3 
selamat ngoding!

output

<img src="https://github.com/evlstari/projectprakmobile/blob/main/dokumentasi/tanpaImage.png" width="250">
<img src="https://github.com/evlstari/projectprakmobile/blob/main/dokumentasi/Fcamera.png" width="250">
<img src="https://github.com/evlstari/projectprakmobile/blob/main/dokumentasi/Fgallery.png" width="250">
