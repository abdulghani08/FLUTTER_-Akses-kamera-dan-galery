package com.example.akseskameradanstorage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
